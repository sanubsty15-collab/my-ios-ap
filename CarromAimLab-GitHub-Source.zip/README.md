# Carrom Aim Lab (iOS)

An independent SwiftUI carrom aiming and trajectory practice app. It does **not** read, modify, or inject into Carrom Pool or any other game.

## Features
- Interactive top-down carrom board
- Drag striker and coins to reposition them
- Purple aim guide
- Approximate first collision prediction
- Cushion reflection preview
- Reset layout

## Requirements
- macOS with Xcode 15 or newer
- iOS 16+
- Swift 5.9+

## Run locally
1. Create a new iOS App project in Xcode named `CarromAimLab` using SwiftUI.
2. Replace the generated app source with `CarromAimLab/CarromAimLabApp.swift` and `CarromAimLab/ContentView.swift` from this repository.
3. Add `CarromBoardView.swift` and `CarromPhysics.swift` to the target.
4. Select an iPhone simulator and press Run.

Alternatively, create a new Xcode project and copy all `.swift` files into its target.

## Build an IPA
An IPA must be built and signed using Xcode and an Apple signing identity/provisioning profile. This source repository alone cannot produce a signed installable IPA. In Xcode, select your iOS device, configure Signing & Capabilities with your Apple team, then use **Product → Archive** and export the app.

## GitHub
Create an empty GitHub repository, then from this folder run:
```bash
git init
git add .
git commit -m "Initial Carrom Aim Lab app"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/CarromAimLab.git
git push -u origin main
```

## Disclaimer
This is a practice simulator, not a Carrom Pool hack. Predictions use simplified 2D geometry and do not model every rule or physical detail of the commercial game.
