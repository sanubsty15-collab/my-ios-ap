import SwiftUI

struct BoardCoin: Identifiable, Equatable {
    let id: UUID
    var position: CGPoint       // normalized board coordinates (0...1)
    var kind: CoinKind

    init(position: CGPoint, kind: CoinKind) {
        self.id = UUID()
        self.position = position
        self.kind = kind
    }
}

enum CoinKind: Equatable {
    case white, black, queen, striker
}

struct BoardState {
    var coins: [BoardCoin]
    var striker: CGPoint
    var aim: CGPoint

    static var standard: BoardState {
        var coins: [BoardCoin] = []
        let center = CGPoint(x: 0.5, y: 0.49)
        coins.append(BoardCoin(position: center, kind: .queen))
        let ring: [(Double, Double)] = [
            (0, -0.045), (0.039, -0.022), (0.039, 0.022),
            (0, 0.045), (-0.039, 0.022), (-0.039, -0.022),
            (0.078, 0), (-0.078, 0), (0.020, -0.083),
            (-0.020, 0.083), (0.020, 0.083), (-0.020, -0.083)
        ]
        for (index, offset) in ring.enumerated() {
            coins.append(BoardCoin(
                position: CGPoint(x: center.x + offset.0, y: center.y + offset.1),
                kind: index.isMultiple(of: 2) ? .white : .black
            ))
        }
        return BoardState(
            coins: coins,
            striker: CGPoint(x: 0.5, y: 0.80),
            aim: CGPoint(x: 0.5, y: 0.38)
        )
    }
}

struct ShotPrediction {
    var end: CGPoint
    var collision: CGPoint?
    var cushionHit: Bool
}

enum CarromPhysics {
    static func predict(
        from start: CGPoint,
        toward target: CGPoint,
        coins: [BoardCoin],
        boardSize: CGSize,
        radius: CGFloat,
        guideScale: CGFloat
    ) -> ShotPrediction {
        let dx = target.x - start.x
        let dy = target.y - start.y
        let length = max(sqrt(dx * dx + dy * dy), 0.001)
        let ux = dx / length
        let uy = dy / length

        let minX = radius
        let maxX = boardSize.width - radius
        let minY = radius
        let maxY = boardSize.height - radius
        let maxDistance = min(boardSize.width, boardSize.height) * 1.35 * guideScale

        var nearest = maxDistance
        var hitPoint: CGPoint?
        for coin in coins {
            let c = CGPoint(x: coin.position.x * boardSize.width,
                            y: coin.position.y * boardSize.height)
            let ox = c.x - start.x
            let oy = c.y - start.y
            let projection = ox * ux + oy * uy
            if projection <= radius * 1.8 { continue }
            let perpendicular2 = ox * ox + oy * oy - projection * projection
            let collisionRadius = radius * 2.05
            if perpendicular2 <= collisionRadius * collisionRadius {
                let distance = projection - sqrt(max(0, collisionRadius * collisionRadius - perpendicular2))
                if distance > 0, distance < nearest {
                    nearest = distance
                    hitPoint = CGPoint(x: start.x + ux * distance, y: start.y + uy * distance)
                }
            }
        }

        var travel = nearest
        var cushion = false
        let tx: CGFloat
        if ux > 0 { tx = (maxX - start.x) / ux }
        else if ux < 0 { tx = (minX - start.x) / ux }
        else { tx = .greatestFiniteMagnitude }
        let ty: CGFloat
        if uy > 0 { ty = (maxY - start.y) / uy }
        else if uy < 0 { ty = (minY - start.y) / uy }
        else { ty = .greatestFiniteMagnitude }
        let wallDistance = min(tx > 0 ? tx : .greatestFiniteMagnitude,
                               ty > 0 ? ty : .greatestFiniteMagnitude)
        if hitPoint == nil {
            travel = min(maxDistance, wallDistance)
            cushion = wallDistance <= maxDistance
        }

        return ShotPrediction(
            end: CGPoint(x: start.x + ux * travel, y: start.y + uy * travel),
            collision: hitPoint,
            cushionHit: cushion
        )
    }
}
