import SwiftUI

struct CarromBoardView: View {
    @Binding var board: BoardState
    let showPrediction: Bool
    let guideLength: Double

    @State private var draggingCoin: UUID?
    @State private var draggingStriker = false
    @State private var draggingAim = false

    private let inset: CGFloat = 24
    private let coinRadius: CGFloat = 12

    var body: some View {
        GeometryReader { geometry in
            let size = CGSize(width: geometry.size.width, height: geometry.size.height)
            let boardRect = CGRect(x: 0, y: 0, width: size.width, height: size.height)
            let strikerPoint = point(board.striker, in: size)
            let aimPoint = point(board.aim, in: size)
            let prediction = CarromPhysics.predict(
                from: strikerPoint,
                toward: aimPoint,
                coins: board.coins,
                boardSize: size,
                radius: coinRadius,
                guideScale: CGFloat(guideLength)
            )

            ZStack {
                RoundedRectangle(cornerRadius: 22)
                    .fill(Color(red: 0.48, green: 0.27, blue: 0.12))
                    .shadow(color: .black.opacity(0.5), radius: 10, y: 7)

                RoundedRectangle(cornerRadius: 16)
                    .fill(
                        LinearGradient(
                            colors: [
                                Color(red: 0.78, green: 0.53, blue: 0.27),
                                Color(red: 0.62, green: 0.37, blue: 0.16),
                                Color(red: 0.77, green: 0.51, blue: 0.25)
                            ],
                            startPoint: .topLeading,
                            endPoint: .bottomTrailing
                        )
                    )
                    .padding(9)

                boardMarkings(size: size)

                if showPrediction {
                    Path { path in
                        path.move(to: strikerPoint)
                        path.addLine(to: prediction.end)
                    }
                    .stroke(Color.purple.opacity(0.28), style: StrokeStyle(lineWidth: 11, lineCap: .round))

                    Path { path in
                        path.move(to: strikerPoint)
                        path.addLine(to: prediction.end)
                    }
                    .stroke(Color(red: 0.72, green: 0.55, blue: 1), style: StrokeStyle(lineWidth: 3, lineCap: .round))

                    Circle()
                        .fill(Color.white)
                        .frame(width: 7, height: 7)
                        .position(prediction.end)

                    if let collision = prediction.collision {
                        Circle()
                            .stroke(Color.cyan, lineWidth: 2)
                            .frame(width: 24, height: 24)
                            .position(collision)
                    }
                    if prediction.cushionHit {
                        Circle()
                            .fill(Color.yellow)
                            .frame(width: 9, height: 9)
                            .position(prediction.end)
                    }
                }

                ForEach(board.coins) { coin in
                    coinView(coin.kind)
                        .frame(width: coin.kind == .queen ? 22 : 20, height: coin.kind == .queen ? 22 : 20)
                        .position(point(coin.position, in: size))
                        .gesture(
                            DragGesture(minimumDistance: 0, coordinateSpace: .named("board"))
                                .onChanged { value in
                                    let p = clamp(value.location, in: size)
                                    if let index = board.coins.firstIndex(where: { $0.id == coin.id }) {
                                        board.coins[index].position = normalized(p, in: size)
                                    }
                                }
                        )
                }

                Circle()
                    .fill(
                        RadialGradient(
                            colors: [.white, Color(red: 0.92, green: 0.78, blue: 0.28), .orange],
                            center: .center, startRadius: 1, endRadius: 18
                        )
                    )
                    .overlay(Circle().stroke(Color.white.opacity(0.9), lineWidth: 2))
                    .frame(width: 30, height: 30)
                    .shadow(color: .black.opacity(0.4), radius: 3, y: 2)
                    .position(strikerPoint)
                    .gesture(
                        DragGesture(minimumDistance: 0, coordinateSpace: .named("board"))
                            .onChanged { value in
                                board.striker = normalized(clamp(value.location, in: size), in: size)
                            }
                    )

                Circle()
                    .fill(Color.purple.opacity(0.15))
                    .overlay(Circle().stroke(Color.purple.opacity(0.9), lineWidth: 2))
                    .frame(width: 28, height: 28)
                    .position(aimPoint)
                    .gesture(
                        DragGesture(minimumDistance: 0, coordinateSpace: .named("board"))
                            .onChanged { value in
                                board.aim = normalized(clamp(value.location, in: size), in: size)
                            }
                    )

                VStack {
                    HStack {
                        Text("PRACTICE BOARD")
                            .font(.system(size: 9, weight: .black, design: .rounded))
                            .tracking(1.4)
                            .foregroundStyle(.black.opacity(0.55))
                        Spacer()
                    }
                    Spacer()
                    HStack {
                        Text("Drag striker, coins or purple target")
                            .font(.system(size: 10, weight: .medium))
                            .foregroundStyle(.black.opacity(0.6))
                        Spacer()
                    }
                }
                .padding(24)
            }
            .clipShape(RoundedRectangle(cornerRadius: 22))
            .contentShape(Rectangle())
            .coordinateSpace(name: "board")
        }
        .aspectRatio(0.88, contentMode: .fit)
    }

    @ViewBuilder
    private func coinView(_ kind: CoinKind) -> some View {
        switch kind {
        case .white:
            Circle().fill(Color(red: 0.95, green: 0.91, blue: 0.77))
                .overlay(Circle().stroke(.black.opacity(0.25), lineWidth: 1.5))
                .shadow(color: .black.opacity(0.35), radius: 2, y: 2)
        case .black:
            Circle().fill(Color(red: 0.12, green: 0.12, blue: 0.15))
                .overlay(Circle().stroke(.white.opacity(0.35), lineWidth: 1))
                .shadow(color: .black.opacity(0.35), radius: 2, y: 2)
        case .queen:
            Circle().fill(Color.red)
                .overlay(Circle().stroke(Color.yellow.opacity(0.9), lineWidth: 2))
                .overlay(Circle().fill(Color.yellow.opacity(0.8)).frame(width: 5, height: 5))
                .shadow(color: .black.opacity(0.35), radius: 2, y: 2)
        case .striker:
            Circle().fill(Color.orange)
        }
    }

    private func boardMarkings(size: CGSize) -> some View {
        ZStack {
            RoundedRectangle(cornerRadius: 8)
                .stroke(Color(red: 0.27, green: 0.13, blue: 0.07), lineWidth: 2)
                .padding(25)

            ForEach(0..<4, id: \.self) { index in
                let y = size.height * (0.20 + CGFloat(index) * 0.20)
                Path { path in
                    path.move(to: CGPoint(x: 35, y: y))
                    path.addLine(to: CGPoint(x: size.width - 35, y: y))
                }
                .stroke(Color.black.opacity(0.06), lineWidth: 1)
            }

            ForEach([
                CGPoint(x: 0.12, y: 0.12), CGPoint(x: 0.88, y: 0.12),
                CGPoint(x: 0.12, y: 0.88), CGPoint(x: 0.88, y: 0.88)
            ], id: \.x) { p in
                Circle()
                    .fill(Color.black.opacity(0.75))
                    .frame(width: 25, height: 25)
                    .position(point(p, in: size))
            }

            Circle()
                .stroke(Color.red.opacity(0.45), lineWidth: 1.5)
                .frame(width: size.width * 0.27, height: size.width * 0.27)
                .position(CGPoint(x: size.width / 2, y: size.height / 2))
        }
    }

    private func point(_ normalized: CGPoint, in size: CGSize) -> CGPoint {
        CGPoint(x: normalized.x * size.width, y: normalized.y * size.height)
    }

    private func normalized(_ point: CGPoint, in size: CGSize) -> CGPoint {
        CGPoint(x: min(max(point.x / max(size.width, 1), 0.04), 0.96),
                y: min(max(point.y / max(size.height, 1), 0.04), 0.96))
    }

    private func clamp(_ point: CGPoint, in size: CGSize) -> CGPoint {
        CGPoint(x: min(max(point.x, inset), size.width - inset),
                y: min(max(point.y, inset), size.height - inset))
    }
}
