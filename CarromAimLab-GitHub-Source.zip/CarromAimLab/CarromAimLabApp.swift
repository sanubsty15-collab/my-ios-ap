import SwiftUI

@main
struct CarromAimLabApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
