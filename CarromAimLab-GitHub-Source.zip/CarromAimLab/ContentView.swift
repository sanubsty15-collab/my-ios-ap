import SwiftUI

struct ContentView: View {
    @State private var board = BoardState.standard
    @State private var showPrediction = true
    @State private var guideLength: Double = 1.0

    var body: some View {
        ZStack {
            Color(red: 0.08, green: 0.07, blue: 0.11).ignoresSafeArea()

            VStack(spacing: 14) {
                HStack {
                    VStack(alignment: .leading, spacing: 3) {
                        Text("CARROM AIM LAB")
                            .font(.system(size: 21, weight: .black, design: .rounded))
                            .tracking(1.2)
                        Text("Independent shot practice")
                            .font(.subheadline)
                            .foregroundStyle(.white.opacity(0.65))
                    }
                    Spacer()
                    Image(systemName: "scope")
                        .font(.system(size: 27, weight: .semibold))
                        .foregroundStyle(.purple)
                }
                .foregroundStyle(.white)
                .padding(.horizontal)

                CarromBoardView(
                    board: $board,
                    showPrediction: showPrediction,
                    guideLength: guideLength
                )
                .padding(.horizontal, 10)
                .frame(maxHeight: .infinity)

                VStack(spacing: 12) {
                    Toggle("Show aim prediction", isOn: $showPrediction)
                        .tint(.purple)
                        .foregroundStyle(.white)

                    HStack {
                        Text("Guide length")
                            .foregroundStyle(.white.opacity(0.8))
                        Slider(value: $guideLength, in: 0.35...1.4)
                            .tint(.purple)
                    }

                    HStack(spacing: 10) {
                        Button {
                            board = .standard
                        } label: {
                            Label("Reset board", systemImage: "arrow.counterclockwise")
                                .frame(maxWidth: .infinity)
                        }
                        .buttonStyle(.bordered)

                        Button {
                            board.striker = CGPoint(x: 0.50, y: 0.78)
                            board.aim = CGPoint(x: 0.50, y: 0.35)
                        } label: {
                            Label("Center shot", systemImage: "scope")
                                .frame(maxWidth: .infinity)
                        }
                        .buttonStyle(.borderedProminent)
                        .tint(.purple)
                    }
                }
                .padding(14)
                .background(.white.opacity(0.07), in: RoundedRectangle(cornerRadius: 18))
                .padding(.horizontal, 14)
                .padding(.bottom, 8)
            }
            .padding(.top, 8)
        }
        .preferredColorScheme(.dark)
    }
}
